<div class="preloader">
    <div class="loader">
        <div class="wrapper">
            <div class="circle circle-1"></div>
            <div class="circle circle-1a"></div>
            <div class="circle circle-2"></div>
            <div class="circle circle-3"></div>
            {{-- <h3 class="text-center text-white">Loading...</h3> --}}
        </div>
    </div>
</div>