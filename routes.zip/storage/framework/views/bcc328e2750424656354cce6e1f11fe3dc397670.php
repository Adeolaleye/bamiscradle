<?php if(session()->get('message')): ?>
<div class="alert alert-success dark alert-dismissible fade show" role="alert">
      <i data-feather="thumbs-up"></i>
      <strong class="m-l-30">Great!</strong> <?php echo e(session()->get('message')); ?>

      <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if(session()->get('error')): ?>
<div class="alert alert-secondary dark alert-dismissible fade show" role="alert">
      <i data-feather="thumbs-down"></i>
      <strong class="m-l-30">Whoops!</strong> <?php echo session()->get('error'); ?>

      <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if(session()->get('warning')): ?>
<div class="alert alert-warning dark alert-dismissible fade show" role="alert">
      <i data-feather="bell"></i>
      <strong>Hey!</strong> <?php echo session()->get('warning'); ?>

      <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if(session()->get('welcomeback')): ?>
<div class="alert alert-success dark alert-dismissible fade show" role="alert">
      <i data-feather="thumbs-up"></i>
      <strong class="m-l-30">Great!</strong> <?php echo e(session()->get('welcomeback')); ?> &#128515
      <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if($errors->any()): ?>
<div class="alert alert-warning dark alert-dismissible fade show" role="alert">
      <i data-feather="bell" class="m-r-30"></i>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?><br>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\bamiscradle\resources\views/includes/alerts.blade.php ENDPATH**/ ?>