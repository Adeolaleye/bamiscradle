<div class="preloader">
    <div class="loader">
        <div class="wrapper">
            <div class="circle circle-1"></div>
            <div class="circle circle-1a"></div>
            <div class="circle circle-2"></div>
            <div class="circle circle-3"></div>
            
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\bamiscradle\resources\views/includes/preloader.blade.php ENDPATH**/ ?>