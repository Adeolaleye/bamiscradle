
    <div class="enrollaction-area ptb-100">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="enrollaction-content">
                        <h2>Do You Want To Your CHild To Be Part Of Us Now?</h2>
                    </div>
                </div>
                <div class="col-lg-6"  style="text-align: center;">
                    <a href="<?php echo e(route('enrollnow')); ?>" target="_blank" class="default-btn">Enroll Now</a>
                </div>
            </div>
        </div>
        <div class="enrollaction-shape">
            <div class="shape-1">
                <img src="<?php echo e(asset('assets/img/enroll/shape-1.png')); ?>" alt="image" />
            </div>
            <div class="shape-2">
                <img src="<?php echo e(asset('assets/img/enroll/shape-2.png')); ?>" alt="image" />
            </div>
        </div>
    </div><?php /**PATH C:\wamp64\www\bamiscradle\resources\views/includes/enroll.blade.php ENDPATH**/ ?>