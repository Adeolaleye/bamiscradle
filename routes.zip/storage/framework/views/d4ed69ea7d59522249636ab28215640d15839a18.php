<?php $__env->startComponent('mail::message'); ?>
<style>
    p{
        color: #5a5454 !important;
    }
    strong{
        font-weight: 600;
        color: #5a5454 !important;
    }
    h4{
        line-height: 18px;
        font-size: 16px;
        font-weight: 600;
        color: #5a5454 !important;
    }
    span{
        color: #615656 !important;
        font-size: 14px;
    }
    .italic {
        color:#d1343a; 
        font-size:15px;
    }
</style>
<?php if( $data['type'] == 'new message'): ?>

<p>Hello Bamiscradle,</p>
<p>
    You have a new contact message from <strong><?php echo e($data['name']); ?></strong><br> 
    <strong>Phone No : </strong><?php echo e($data['phone']); ?><br>
    <strong>Email : </strong> <?php echo e($data['name']); ?>

<p>
    <h4>Body Of Message</h4>
<p><?php echo e($data['message']); ?></p>
<p>Note that <?php echo e($data['name']); ?> awaits your response.</p>
<span>Sent on <?php echo e(date('d, M Y @ h:i:s', strtotime($data['date']))); ?>.</span>
<?php endif; ?>

<?php if( $data['type'] == 'message recieved'): ?>

<p>Hello <?php echo e($data['name']); ?>,</p>
<p>
    Your contact message has been recieved, you will hear from us shortly.
<p>
<i class="italic">At Bamiscradle, we foster our students for learning, encourage them to try new and exciting things and give them a solid foundation to build on.</i><br>
<span>Sent on <?php echo e(date('d, M Y, @ h:i:s', strtotime($data['date']))); ?>.</span>
<?php endif; ?>
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\bamiscradle\resources\views/emails/contact.blade.php ENDPATH**/ ?>