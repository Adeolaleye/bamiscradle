<?php $__env->startComponent('mail::message'); ?>
<style>
    p{
        color: #5a5454 !important;
    }
    strong{
        font-weight: 600;
        color: #5a5454 !important;
    }
    h4{
        line-height: 18px;
        font-size: 16px;
        font-weight: 600;
        color: #5a5454 !important;
    }
    span{
        color: #615656 !important;
        font-size: 14px;
    }
    .italic {
        color:#d1343a; 
        font-size:15px;
    }
</style>
<?php if( $data['type'] == 'new applicant'): ?>

<p>Hello Bamiscradle,</p>
<p>
    You have a new new applicant from Bamiscradle enrollment form, below are the details<br> 
    <strong>Child's Name : </strong><?php echo e($data['name']); ?><br>
    <strong>Child's Age : </strong><?php echo e($data['age']); ?><br>
    <strong>Child's DOB : </strong><?php echo e(date('d, M Y', strtotime($data['dob']))); ?><br>
    <strong>Child's Gender : </strong><?php echo e($data['gender']); ?><br>
    <strong>Disability : </strong><?php echo e($data['specify_dis']); ?><br>
    <strong>Service: </strong><?php echo e($data['service']); ?>

<p>
    <h4>Parent's Details</h4>
<p>
    <strong>Parent Name : </strong> <?php echo e($data['p_name']); ?><br>
    <strong>Parent Phone : </strong><?php echo e($data['phone']); ?><br>
    <strong>Parent Email : </strong> <?php echo e($data['email']); ?><br>
    <strong>Address : </strong><?php echo e($data['address']); ?><br>
    <strong>Place Of Work : </strong><?php echo e($data['place_of_work']); ?><br>
    <strong>Place Of Work Address : </strong> <?php echo e($data['place_of_work_address']); ?><br>
</p>
<h4>Who To Call For Emergency</h4>
<p>
    <strong>Name : </strong> <?php echo e($data['p_name']); ?><br>
    <strong>Phone : </strong><?php echo e($data['phone']); ?><br>
    <strong>Email : </strong> <?php echo e($data['who_to_call_email']); ?><br>
    <strong>Address : </strong><?php echo e($data['address']); ?><br>
</p><h4>Pick Up Details 1</h4>
<p>
    <strong>Name : </strong> <?php echo e($data['pickup_name_1']); ?><br>
    <strong>Phone : </strong><?php echo e($data['pickup_phone_1']); ?><br>
    <strong>Email : </strong> <?php echo e($data['pickup_email_1']); ?><br>
    <strong>Address : </strong><?php echo e($data['pickup_address_1']); ?><br>
    <strong>Picture: </strong> <img src="pictures/<?php echo e($data['pickup_picture_1']); ?>">
</p>
</p><h4>Pick Up Details 2</h4>
<p>
    <strong>Name : </strong> <?php echo e($data['pickup_name_2']); ?><br>
    <strong>Phone : </strong><?php echo e($data['pickup_phone_2']); ?><br>
    <strong>Email : </strong> <?php echo e($data['pickup_email_2']); ?><br>
    <strong>Address : </strong><?php echo e($data['pickup_address_2']); ?><br>
    <strong>Picture: </strong> <img src="pictures/<?php echo e($data['pickup_picture_2']); ?>">
</p>
<p>Note that <?php echo e($data['p_name']); ?> awaits your feedback.</p>
<span>Enrolled on <?php echo e(date('d, M Y @ h:i:s', strtotime($data['date']))); ?>.</span>
<?php endif; ?>

<?php if( $data['type'] == 'application recieved'): ?>

<p>Hello <?php echo e($data['p_name']); ?>,</p>
<p>
    Your child's application has been recieved by bamiscradle, kindly check your details below:<br> 
    <strong>Child's Name : </strong><?php echo e($data['name']); ?><br>
    <strong>Child's Age : </strong><?php echo e($data['age']); ?><br>
    <strong>Child's DOB : </strong><?php echo e(date('d, M Y', strtotime($data['dob']))); ?><br>
    <strong>Child's Gender : </strong><?php echo e($data['gender']); ?><br>
    <strong>Disability : </strong><?php echo e($data['specify_dis']); ?><br>
    <strong>Service: </strong><?php echo e($data['service']); ?>

<p>
    <h4>Parent's Details</h4>
<p>
    <strong>Parent Name : </strong> <?php echo e($data['p_name']); ?><br>
    <strong>Parent Phone : </strong><?php echo e($data['phone']); ?><br>
    <strong>Parent Email : </strong> <?php echo e($data['email']); ?><br>
    <strong>Address : </strong><?php echo e($data['address']); ?><br>
    <strong>Place Of Work : </strong><?php echo e($data['place_of_work']); ?><br>
    <strong>Place Of Work Address : </strong> <?php echo e($data['place_of_work_address']); ?><br>
</p>
<h4>Who To Call For Emergency</h4>
<p>
    <strong>Name : </strong> <?php echo e($data['p_name']); ?><br>
    <strong>Phone : </strong><?php echo e($data['phone']); ?><br>
    <strong>Email : </strong> <?php echo e($data['who_to_call_email']); ?><br>
    <strong>Address : </strong><?php echo e($data['address']); ?><br>
</p><h4>Pick Up Details 1</h4>
<p>
    <strong>Name : </strong> <?php echo e($data['pickup_name_1']); ?><br>
    <strong>Phone : </strong><?php echo e($data['pickup_phone_1']); ?><br>
    <strong>Email : </strong> <?php echo e($data['pickup_email_1']); ?><br>
    <strong>Address : </strong><?php echo e($data['pickup_address_1']); ?><br>
    <strong>Picture: </strong> <img src="pictures/<?php echo e($data['pickup_picture_1']); ?>">
</p>
</p><h4>Pick Up Details 2</h4>
<p>
    <strong>Name : </strong> <?php echo e($data['pickup_name_2']); ?><br>
    <strong>Phone : </strong><?php echo e($data['pickup_phone_2']); ?><br>
    <strong>Email : </strong> <?php echo e($data['pickup_email_2']); ?><br>
    <strong>Address : </strong><?php echo e($data['pickup_address_2']); ?><br>
    <strong>Picture: </strong> <img src="pictures/<?php echo e($data['pickup_picture_2']); ?>">
</p>
<p>Perhaps you made mistake while entering any of this details, or you have further enquires, follow this <a href="">link</a> to contact us</p>
<span>Enrolled on <?php echo e(date('d, M Y @ h:i:s', strtotime($data['date']))); ?>.</span>
<?php endif; ?>
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\bamiscradle\resources\views/emails/enroll.blade.php ENDPATH**/ ?>